def get_schema_metadata():
    # Ideally fetch dynamically from DB
    return """
    Tables:
    - users(id, name, country, signup_date)
    - orders(id, user_id, product, amount, date)
    - products(id, name, category, price)
    """
