from fastapi import FastAPI
from pydantic import BaseModel
from sqlalchemy import text
from db import engine
from utils import get_schema_metadata
import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

app = FastAPI()

class QueryRequest(BaseModel):
    question: str

@app.post("/ask")
def ask_data(req: QueryRequest):
    schema = get_schema_metadata()
    prompt = f"""
    You are an assistant converting natural language questions into MySQL queries.
    Schema:
    {schema}

    Question: \"{req.question}\"
    Return the SQL query or say 'This kind of data does not exist.'
    """

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    sql = response.choices[0].message.content.strip()

    if "does not exist" in sql.lower():
        return {"message": sql}

    try:
        with engine.connect() as conn:
            result = conn.execute(text(sql))
            rows = [dict(row._mapping) for row in result]
            return {"result": rows}
    except Exception as e:
        return {"error": str(e)}
