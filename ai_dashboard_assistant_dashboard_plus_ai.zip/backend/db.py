from sqlalchemy import create_engine

DB_URI = "mysql+pymysql://user:password@localhost/db"
engine = create_engine(DB_URI)
