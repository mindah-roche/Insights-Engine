import streamlit as st
import requests
import pandas as pd

st.title("AI Dashboard Assistant")

question = st.text_input("Ask your question:")
if question:
    response = requests.post("http://localhost:8000/ask", json={"question": question})
    data = response.json()

    if "result" in data:
        st.dataframe(pd.DataFrame(data["result"]))
    elif "message" in data:
        st.warning(data["message"])
    else:
        st.error(data.get("error", "Something went wrong."))
